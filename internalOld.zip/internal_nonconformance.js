//One function
function dispositionChecked(button)
{
	if(document.getElementById(button).checked == true)
	{
		document.getElementById('none').checked = false;
	}
}

//Another function
function dispostionNoneChecked()
{	
	//if this checkbox is checked, no other checkboxes can be checked
	//alert("test");
	if(document.getElementById('none').checked == true)
	{
		document.getElementById('engChange').checked = false;
		document.getElementById('supply').checked = false;
		document.getElementById('other').checked = false;
	}
}
//A function that checks if the 'other' checkbox is checked or not
function otherChecked()
{
	var otherDesc;
	var fieldArea;
	//if(document.getElementById('other').checked == true)
	//{
		//the option 'none' cannot be checked if this is
		document.getElementById('none').checked = false;
		/*otherDesc = document.createElement("otherDesc");
		fieldArea = document.getElementById('fieldArea');
				
		otherDesc.type = "text";
		otherDesc.setAttribute('size', 25);
		fieldArea.appendChild(otherDesc);
	}

	else
	{
		alert("not checked");
		//document.fieldArea.removeChild(otherDesc);
	}*/
}

function verify(f)
{
	var errors = false;
	var rField = new Array(45);
	
	var supplier;
	var fPartNo;
	var rev;
	var vPartNo;
	var orderDate;
	var desc;
	var serial_no; 
	var pricePerUnit;
	var buyer;
	var inspectionLevel;
	var poNo;
	var qtyReceived;
	var qtyRejected;
	var account;
	var date;
	var nonConformance;
	var rootCause;
	var correctiveAction;
	var eng;
	var sCar;
	var other;
	var none;
	var repair;
	var rework;
	var use;
	var scrap;
	var returnToVendor;
	var replacementRequired;
	var actionee;
	var dueDate;
	var project;
	var projectDate;
	var purchase;
	var purchaseDate;
	var quality;
	var qcDate;
	var operation;
	var operationDate;
	var techical;
	var techDate;
	var prodControl;
	var prodDate;
	var preparedBy;
	var preparedDate;
	
	var firstError = false;
	var errorField;
	var blankCheck = false;
	var blankCount = 0;
		
	for(var i = 0; i < f.length; i++)
	{
		var e = f.elements[i];
		if ((e.value == null) || (e.value == "") || isblank(e))
		{
			blankCheck = true;
		}
		else
		{
			blankCheck = false;
		}
	//alert(rField[i] + " " + blankCheck);
	//Tests the validity of required fields.
		if ((e.type == "text" || e.type == "textarea") && e.required)
		{
				
		//if ((e.value == null) || (e.value == "") || isblank(e))
			if (blankCheck)
			{
				//alert(rField[i] + " 1");
				errors = true;
				if (!firstError)
				{
					errorField = e;
					alert("Please enter the " + rField[i]);
					errorField.focus();
					firstError = true;
				}
				continue;
			}
			else
			{
				//alert("not blank " + rField[i]);
				if(e.dateCheck)
				{
					//alert("Required date check!");
					firstError = checkDateFormat(e, rField[i], firstError);
				}
			}					
			//firstError = formatCheck(e, f, i, rField[i], firstError);
				if(e.numberTest || e.numeric)
					firstError = numericTest(e, rField[i], firstError);
		}
		else
		{
			//alert("not required " + rField[i]);
			if(!blankCheck)
			{
				//alert("Not blank " + rField[i]);
				if(e.dateCheck)
				{
					//alert("Optional date check!");
					firstError = checkDateFormat(e, rField[i], firstError);
				}
				
				if(e.numberTest || e.numeric)
					firstError = numericTest(e, rField[i], firstError);
			}
		}
	}	
}


function numericTest(e, fieldName, firstError)
{
	var v = e.value;
	if (isNaN(v))
	{
		if (!firstError)
		{
			alert("The " + fieldName + " must be numeric.");
			e.focus();
			firstError = true;
		}
	}
	
	if (v <= 0)
	{
		if (!firstError)
		{
			alert("The " + fieldName + " must be greater than 0.");
			e.focus();
			firstError = true;
		}		
	}
	return firstError;
}

function isblank(e)
{
	s = e.value;
	for (var b = 0; b < s.length; b++)
	{
		var c = s.charAt(b);
		if((c != " ") && (c != "\n") && (c != "\t")) 
			return false;
	}
	return true;
}

function checkDateFormat(e, fieldName, firstError)
{
	var v = e.value;
	var dateFormat = /^\d{1,2}(\-|\/|\.)\d{1,2}\1\d{4}$/;
	if (!dateFormat.test(v))
	{
		alert("The " + fieldName + " must be in the following format: dd-mm-yyyy");
		e.focus();
		firstError = true;
	}
	return firstError;
}