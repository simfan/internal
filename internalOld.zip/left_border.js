/*function toggleDisplay(divID)
{
	
	if (divID.style.display == "inline")
		divID.style.display = "none";
		
	if (divID.style.display == "none")
		divID.style.display = "inline";
}*/