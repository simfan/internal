<html>
	<head>
	</head>
	<body>
		<form>
			<table>
				<tr>
					<td>ITR Number</td>
					<td><input type = "text" name = "itrNo" id = "itrNo" size = 6 maxlength = 6 /></td>
				</tr>
				<tr>
					<td>Inspection Date</td>
					<td><input type = "text" name = "iDate" id = "iDate" size = 10 maxlegth = 10 /></td>
				</tr>
				<tr>
					<td>Station</td>
					<td><input type = "text" name = "station" id = "station" size = 20 maxlength = 20 /></td>
				</tr>
				<tr>
					<td>Dept. Manager</td>
					<td><input type = "text" name = "manager1" id = "manager1" size = 25 maxlength = 25 /></td>
				</tr>
				<tr>
					<td>Inspector</td>
					<td><input type = "text" name = "inspector" id = "inspector" size = 25 maxlength = 25 /></td>
				</tr>
				<tr>
					<td>Part No.</td>
					<td><input type = "text" name = "partNo" id = "partNo" size = 20 maxlength = 20 /></td>
				</tr>
				<tr>
					<td>Operator</td>
					<td><input type = "text" name = "operator" id = "operator" size = 25 maxlength = 25 /></td>
				</tr>
				<tr>
					<td>Reviewed By</td>
				</tr>
				<tr>
					<td>Department Manager</td>
					<td><input type = "text" name = "manager2" id = "manager2" size = 25 maxlength = 25 /></td>
				</tr>
			</table>
			<input type = "submit" name = "submit" id = "submit" value = "Search" />
		</form>
	</body>
</html>	