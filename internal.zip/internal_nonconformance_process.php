<?php
	ob_start();
	$host = "192.168.10.129";
	$user = "postgres";
	$pass = "pass";
	$db = "inven";
	$conn = pg_connect("host=$host dbname=$db user=$user password=$pass");
	if(!$conn)
	{
		die('Could not connect to database');
	}
	//incr_no will either be 0 or the number to be updated	
	$form_type = $_POST['formType'];

	$record_no = htmlentities($_POST['incrNo']);
	$table = 'incr';
	$record_type = 'incr_no';

	$supplier = htmlentities($_POST['supplier']);
	$f_part_no = htmlentities($_POST['fPartNo']);
	//print $f_part_no;
	$rev = htmlentities($_POST['rev']);
	$v_part_no = htmlentities($_POST['vPartNo']);
	$order_date = htmlentities($_POST['orderDate']);
	$desc = htmlentities($_POST['desc']);
	$serial_no = htmlentities($_POST['serial']);
	$price = htmlentities($_POST['ppu']);
	$buyer = htmlentities($_POST['buyer']);
	$level = htmlentities($_POST['level']);
	$po_no = htmlentities($_POST['po']);
	$qty_rec = htmlentities($_POST['qtyRec']);
	$qty_rejected = htmlentities($_POST['qtyRejected']);
	$account_no = htmlentities($_POST['account']);
	$date = htmlentities($_POST['date']);
	$non_con = htmlentities($_POST['descNonCon']);
	$root_cause = htmlentities($_POST['rootCause']);
	if (isset($_POST['engChange']))
		$eng = 1;
	else 
		$eng = 0;
	if (isset($_POST['supply']))
		$s_car = 1;
	else
		$s_car = 0;
	if (isset($_POST['other']))
		$other = 1;
	else
		$other = 0;
	if (isset($_POST['none']))
		$none = 1;
	else
		$none = 0;
	$repair = htmlentities($_POST['repair']);
	$rework = htmlentities($_POST['rework']);
	$use = htmlentities($_POST['use']);
	$scrap = htmlentities($_POST['scrap']);
	$return = htmlentities($_POST['return']);
	$replace = htmlentities($_POST['replace']);
	$actionee = htmlentities($_POST['actionee']);
	$due_date = htmlentities($_POST['dueDate']);
	$action = htmlentities($_POST['action']);
	$project = htmlentities($_POST['project']);
	$project_date = htmlentities($_POST['projectDate']);
	$purchasing = htmlentities($_POST['purchasing']);
	$purchasing_date = htmlentities($_POST['purchasingDate']);
	$quality = htmlentities($_POST['quality']);
	$quality_date = htmlentities($_POST['qualityDate']);
	$operation = htmlentities($_POST['operation']);
	$operation_date = htmlentities($_POST['operation_date']);
	$tech = htmlentities($_POST['tech']);
	$tech_date = htmlentities($_POST['techDate']);
	$prod_control = htmlentities($_POST['prod']);
	$prod_date = htmlentities($_POST['prodDate']);
	$prep = htmlentities($_POST['prep']);
	$prep_date = htmlentities($_POST['prepDate']);
	
	if($_POST['submit'] == 'Submit')
	{
		
		$query_max = "SELECT * FROM " . $table . " ORDER BY incr_no DESC LIMIT 1";
		$result_max = pg_query($conn, $query_max) or die("Error in query: $query_max. " . pg_last_error($conn));
		$max_row = pg_fetch_array($result_max);
		$max_incr_no = $max_row['incr_no'];
		$incr_no = $max_incr_no + 1;
		print $incr_no;
		$query = "INSERT INTO incr(incr_no, incr_supplier, incr_fargo_part, incr_rev, incr_vendor_part, incr_order_date, incr_desc, incr_serial_no, incr_price, incr_buyer, incr_inspection_level, incr_po_no, incr_qty_received, incr_qty_rejected, incr_account_no, incr_date, incr_noncon, incr_root_cause, incr_eng, incr_s_car, incr_other, incr_none, incr_repair_qty, incr_rework_qty, incr_as_is_qty, incr_scrap_qty, incr_return_qty, incr_replace_qty, incr_actionee, incr_due_date, incr_corrective_action, incr_project, incr_project_date, incr_purchasing, incr_purchasing_date, incr_quality, incr_quality_date, incr_operation, incr_operation_date, incr_tech, incr_tech_date, incr_prod_control, incr_prod_date, incr_prepared_by, incr_prepared_date) VALUES('" . $incr_no . "', '" . $supplier . "', '" . $f_part_no . "', '" .  $rev . "', '" .  $v_part_no . "', '" .  $order_date . "', '" .  $desc . "', '" .  $serial_no . "', '" .  $price . "', '" .  $buyer . "', '" .  $level . "', '" .  $po_no . "', '" .  $qty_rec . "', '" .  $qty_rejected . "', '" .  $account_no . "', '" .  $date . "', '" .  $non_con . "', '" .  $root_cause . "', '" .  $eng . "', '" .  $s_car . "', '" .  $other . "', '" .  $none . "', '" .  $repair . "', '" .  $rework . "', '" .  $use . "', '" .  $scrap . "', '" . $return . "', '" . $replace . "', '" .  $actionee . "', '" . $due_date . "', '" . $action . "', '" . $project . "', '" . $project_date . "', '" . $purchasing . "', '" . $purchasing_date  . "', '" . $quality . "', '" . $quality_date . "', '" . $operation . "', '" . $operation_date . "', '" . $tech . "', '" . $tech_date . "', '" . $prod_control . "', '" . $prod_date . "', '" . $prep . "', '" . $prep_date . "')";
	}
	
	if($_POST['submit'] == 'Edit')
	{
		$query = "UPDATE incr SET incr_supplier = '" . $supplier . "', incr_fargo_part = '" . $f_part_no . "', incr_rev = '" . $rev . "', incr_vendor_part = '" . $v_part_no . "', incr_order_date = '" . $order_date . "', incr_desc = '" . $desc . "', incr_serial_no = '" . $serial_no . "', incr_price = '" . $price . "', incr_buyer = '" . $buyer . "', incr_inspection_level = '" . $level . "', incr_po_no = '" . $po_no . "', incr_qty_received = '" . $qty_rec . "', incr_qty_rejected = '" . $qty_rejected . "', incr_account_no = '" . $account_no . "', incr_date = '" . $date . "', incr_noncon = '" . $non_con . "', incr_root_cause = '" . $root_cause . "', incr_eng = '" . $eng . "', incr_s_car = '" . $s_car . "', incr_other = '" . $other . "', incr_none = '" . $none . "', incr_repair_qty = '" . $repair . "', incr_rework_qty = '" . $rework . "', incr_as_is_qty = '" . $use . "', incr_scrap_qty = '" . $scrap . "', incr_return_qty = '" . $return . "', incr_replace_qty = '" . $replace . "', incr_actionee = '" . $actionee . "', incr_due_date = '" . $due_date . "', incr_corrective_action = '" . $action . "', incr_project = '" . $project . "', incr_project_date = '" . $project_date . "', incr_purchasing = '" . $purchasing . "', incr_purchasing_date = '" . $purchasing_date . "', incr_quality = '" . $quality . "', incr_quality_date = '" . $quality_date . "', incr_operation = '" . $operation . "', incr_operation_date = '" . $operation_date . "', incr_tech = '" . $tech . "', incr_tech_date = '" . $tech_date . "', incr_prod_control = '" . $prod_control . "', incr_prod_date = '" . $prod_date . "', incr_prepared_by = '" . $prep . "', incr_prepared_date = '" . $prep_date . "' WHERE incr_no = '" . $record_no . "'";
	}
	
	if($_GET['action'] == 'delete')
	{
		$car_no = $_GET['carno'];
		$query = "DELETE FROM incr WHERE incr_no  = '" . $record_no . "'";
	}
	print $query;
	$result = pg_query($conn, $query) or die("Error in query: $query." . pg_last_error($conn));

	
	//$result = ($conn, $query) or die("Error in query: $query" . pg_last_error($conn));
	$query = "COMMIT";
	$result = pg_query($conn, $query) or die("Error in query: $query" . pg_last_error($conn));
	//header("Location: index.php");
	ob_end_flush();
?>