<html>
<head>
<?php
	$host = "192.168.10.129";
	$user = "postgres";
	$pass = "pass";
	$db = "inven";
	$conn = pg_connect("host=$host dbname=$db user=$user password=$pass");
	if(!$conn)
	{
		die('Could not connect to database');
	}
	$login = "login.php?location=table&status=" . $status . "&plant=" .$location;
	$login_text = "Log In";	
	$match = 0;
	
	if(isset($_COOKIE['ID_my_site']))
	{
		$username = $_COOKIE['ID_my_site'];
		$password = $_COOKIE['Key_my_site'];
		
		$check = "SELECT * FROM car_login WHERE car_username = '$username'";
		$check_results = pg_query($conn, $check) or die("Error in query: $query. " . pg_last_error($conn));
		$user_info = pg_fetch_array($check_results);
		
		if($password == $user_info['car_password'])
		{
			$login = "logout.php?location=table&status=" . $status . "&plant=" . $location;
			$login_text = "Log Out";
			if ($user_info['plant1'] == 'A')
			{
				$match = 1;
			}
			else
			{
				for($i == 0; $i < 4; $i++)
				{
					$j = $i + 1;
					$plant_name = 'plant' . $j;
					
					if($location == $user_info[$plant_name])// || $location = "A")
					{
						$match = 1;
						break;
					}
				}
			}
		}
	}	
	$db_fields = array('itr_no', 'inspection_date', 'station', 'dept_manager_1', 'inspector', 'part_no', 'operator', 'inspection_summary', 'discrepancies', 'interim_containment', 'corrective_action', 'result', 'dept_manager_2', 'managaer_review_date', 'dept_head', 'head_review_date');
	
	$html_fields = array('itrNo', 'inspectionDate', 'station', 'deptManager1', 'inspector', 'partNo', 'operator', 'summary', 'discrepancies', 'containment', 'correctiveAction', 'result', 'deptManager2', 'reviewDate1', 'qaDeptHead', 'reviewDate2');
	
	$table_headings = array('ITR NO', 'Inspection Date', 'Station', 'Dept Manager', 'Inspector', 'Part No', 'Operator', 'Inspection Summary', 'Discrepancies', 'Interim Containment', 'Corrective/</br>Preventive Action', 'Result of</br>Preventive Action', 'Department Manager', 'Date', 'QA Department Head', 'Date');
	
	$size = count($html_fields);
	$query = "SELECT * FROM itr ";
	$field_count = 0;
	
	for($i = 0; $i < $size; $i++)
	{
		$link_switch = 0;
		$enter_switch = 0;
		if($_POST[$html_field[$i]])	
			$field_value[$i] = $_POST[$html_field[$i]];
		if($_GET[$html_field[$i]])
			$field_value[$i] = $_GET[$html_field[$i]];
		
		if($i >= 16 && $i <= 19)
		{
			if (isset($_POST[$html_field[$i]]))
			{
				$link_switch = 1;
				$enter_switch = 1;
			}
		}
		else
		{
			if ($_POST[$html_field[$i]] != '')
			{
				$link_switch = 1;
				$enter_switch = 1;
			}
		}
		//print $enter_switch;				
		if($enter_switch == 1)
		{
			if($field_count == 0)
				$query_conditions = "WHERE ";
			if ($field_count > 0)
				$query_conditions .= "AND ";
			$query_conditions .= "$db_field[$i] = '" . $field_value[$i] . "' " ;
			$field_count++;
		}
			
		if($link_switch == 1)
		{
			if($switch_count == 0)
				$link = "?" . $html_field[$i] . "=" . $field_value[$i];
			if($switch_count > 0)
				$link .= "&" . $html_field[$i] . "=" . $field_value[$i];
			$switch_count++;
		}
	}
	$query .= $query_conditions;
	$query .= "ORDER BY itr_no";
	$result = pg_query($conn, $query) or die("Error in query: $query " . pg_last_error($conn));
	$rows = pg_num_rows($result);


?>
<script type = "text/javascript">
	var i;
	var match = <?php echo $match;?> ;
	var itrNo = new Array();
	var inspectionDate = new Array();
	var station = new Array();
	var deptManager1 = new Array();
	var inspector = new Array();
	var partNo = new Array();
	var operator = new Array();
	var summary = new Array();
	var discrepancies = new Array();
	var containment = new Array();
	var correctiveAction = new Array();
	var result = new Array();
	var deptManager2 = new Array();
	var reviewDate1 = new Array();
	var qaDeptHead = new Array();
	var reviewDate2 = new Array();
	var itr = new Array();
	var fieldNames = new Array();
	var fieldValues = new Array();

<?php
	for ($i = 0; $i < $rows; $i++)
	{
		//$itr = pg_fetch_array($result);
		$itr = pg_fetch_array($result);
		$itr_no = $itr['itr_no'];
		if ($itr_no == '')
			$itr_no = '&nbsp';
		$inspection_date = $itr['inspection_date'];
		if ($inspection_date == '')
			$inspection_date = '&nbsp';
		$station = $itr['station'];
		if ($station == '')
			$station = '&nbsp';
		$dept_manager_1 = $itr['dept_manager_1'];
		if ($dept_manager_1 == '')
			$dept_manager_1 = '&nbsp';
		$inspector = $itr['inspector'];
		if ($inspector == '')
			$inspector = '&nbsp';
		$part_no = $itr['part_no'];
		if ($part_no == '')
			$part_no = '&nbsp';
		$operator = $itr['operator'];
		if ($operator == '')
			$operator = '&nbsp';
		$summary = $itr['inspection_summary'];
		if ($summary == '')
			$summary = '&nbsp';
		$discrepancies = $itr['discrepancies'];
		if ($discrepancies == '')
			$discrepancies = '&nbsp';
		$containment = $itr['interim_containment'];
		if ($containment == '')
			$containment = '&nbsp';
		$corrective_action = $itr['corrective_action'];
		if ($corrective_action == '')
			$corrective_action = '&nbsp';
		$results = $itr['result'];
		if ($results == '')
			$results = '&nbsp';
		$dept_manager_2 = $itr['dept_manager_2'];
		if ($dept_manager_2 == '')
			$dept_managar_2 = '&nbsp';
		$manager_review_date = $itr['manager_review_date'];
		if ($manager_review_date == '')
			$manager_review_date = '&nbsp';
		$dept_head = $itr['dept_head'];
		if ($dept_head == '')
			$dept_head = '&nbsp';
		$head_review_date = $itr['head_review_date'];
		if ($head_review_date == '')
			$head_review_date = '&nbsp';
			
		?>
			i = <?php echo $i; ?>;
			itrNo[i] = <?php echo "'" . $itr_no . "'"; ?>;
			inspectionDate[i] = <?php echo "'" . $inspection_date . "'"; ?>;
			station[i] = <?php echo "'" . $station . "'"; ?>;
			deptManager1[i] = <?php echo "'" . $dept_manager_1 . "'"; ?>;
			inspector[i] = <?php echo  "'" . $inspector . "'"; ?>;
			partNo[i] = <?php echo "'" . $part_no . "'"; ?>;
			operator[i] = <?php echo "'" . $operator . "'"; ?>;
			summary[i] = <?php echo "'" . $summary . "'"; ?>;
			discrepancies[i] = <?php echo "'" . $discrepancies . "'"; ?>;
			containment[i] = <?php echo "'" . $containment . "'"; ?>;
			correctiveAction[i] = <?php echo "'" . $corrective_action . "'"; ?>;
			result[i] = <?php echo "'" . $results . "'"; ?>;
			deptManager2[i] = <?php echo "'" . $dept_manager_2 . "'";?>;
			reviewDate1[i] = <?php echo "'" . $manager_review_date . "'"; ?>;
			qaDeptHead[i] = <?php echo "'" . $dept_head . "'"; ?>;
			reviewDate2[i] = <?php echo "'" . $head_review_date . "'"; ?>;
			itr[i] = [itrNo[i], inspectionDate[i], station[i], deptManager1[i], inspector[i], partNo[i], operator[i], summary[i], discrepancies[i], containment[i], correctiveAction[i], result[i], deptManager2[i], reviewDate1[i], qaDeptHead[i], reviewDate2[i]];
		<?php 
		}
					
		for ($i = 0; $i <$size; $i++)
		{?>
			i = <?php echo $i; ?>;
			fieldNames[i] = <?php echo "'" . $table_headings[$i] . "'"; ?>;
			fieldValues[i] = <?php echo "'" . $html_fields[$i]  . "'"; ?>;
			//alert ("Field Values: " + fieldValues[i]);
		<?php
		}
		
		for ($i = 0; $i < $rows; $i++)
		{?>	
			i = <?php echo $i; ?>;
			<?php
				for($j = 0; $j < $size; $j++)	
			{
		?>
			j = <?php echo $j; ?>;
		<?php
			}
		}
		?>
		function sortTableAlpha(tableField, sorted)
		{
				var sortText = fieldValues[tableField] + "Sort";
				var direction = document.getElementById(sortText).value;
				var fieldCount = <?php echo $size;?>;
				var fieldName;
				var viewText;
				var editText;
				var deleteText;
				itr.sort(function(a,b)
				{
					var fieldA = a[tableField].toLowerCase(), fieldB = b[tableField].toLowerCase()
					if (fieldA < fieldB)
						return -1
					if (fieldA > fieldB)
						return 1
					if (fieldA === fieldB)
						return(a[0] - b[0])
				})
				if (direction == -1)
				itr.reverse();
				for(var i = 0; i < fieldCount; i++)
				{	
					fieldName = fieldValues[i] + "Sort";
					document.getElementById(fieldName).value = 1
				}
				for(var i = 0; i < tableRows; i++)
				{
					viewText = "viewLink" + i;
					editText = "editLink" + i;
					deleteText = "deleteLink" + i;
			
					document.getElementById(viewText).href = "internal_trouble.php?itrNo="+itr[i][0]+"&action=view";
					if (match == 1)
					{
						document.getElementById(editText).href = "internal_trouble.php?itrNo="+itr[i][0]+ "&action=edit";
					}	
					/*document.getElementById(deleteText).href = "internal_trouble_process.php?itrNo="+itr[i][0]+"&action=delete";*/
					for(var j = 0; j < fieldCount; j++)
					{
						documentText = fieldValues[j] + i;
						document.getElementById(documentText).innerHTML = itr[i][j];
					}
			
					//document.getElementById(itrText).innerHTML = totalRows;
			
				}
				if (direction == 1)
					newDirection = -1;
				if (direction == -1)
					newDirection = 1;
				document.getElementById(sortText).value = newDirection;
			}
			function sortTableNum(tableField, sorted)
			{
				var sortText = fieldValues[tableField] + "Sort";
				var direction = document.getElementById(sortText).value;
				var fieldCount = <?php echo $size;?>;
				var fieldName;
				var viewText;
				var editText;
				var deleteText;
				itr.sort(function(a,b)
				{
					var fieldA
					var fieldB
					if (a[tableField] == '')
						fieldA = 0
					else
						fieldA = a[tableField].toLowerCase()
			
					if (b[tableField] == '')
						fieldB = 0
					else
						fieldB = b[tableField].toLowerCase()
					
					if (fieldA === fieldB)
						return(a[0] - b[0])
					else
						return(fieldA - fieldB)
				})
		
				if (direction == -1)
					itr.reverse();
				
				for(var i = 0; i < fieldCount; i++)
				{	
					fieldName = fieldValues[i] + "Sort";
					document.getElementById(fieldName).value = 1;
				}
				
				for(var i = 0; i < tableRows; i++)
				{
					viewText = "viewLink" + i;
					editText = "editLink" + i;
					deleteText = "deleteLink" + i;
			
					document.getElementById(viewText).href = "internal_trouble.php?itrNo="+itr[i][0]+"&action=view";
					if (match == 1)
					{
						document.getElementById(editText).href = "internal_trouble.php?itrNo="+itr[i][0]+"&action=edit";
					}
					/*document.getElementById(deleteText).href = "internal_trouble_process.php?itrNo="+itr[i][0]+"&action=delete";*/
					for(var j = 0; j < fieldCount; j++)
					{
						documentText = fieldValues[j] + i;
						document.getElementById(documentText).innerHTML = itr[i][j];
					}
				//	itrText = "itrNo" + i;
			//...
			
			
			//document.getElementById(itrText).innerHTML = totalRows;
			
				}
				if (direction == 1)
					newDirection = -1;
				if (direction == -1)
					newDirection = 1;
				document.getElementById(sortText).value = newDirection;		
			}
			function sortTableDate(tableField, sorted)
			{
				var sortText = fieldValues[tableField] + "Sort";
				var direction = document.getElementById(sortText).value;
				var fieldCount = <?php echo $size;?>;
				var fieldName;
				var viewText;
				var editText;
				var deleteText;
		
				itr.sort(function(a,b)
				{
					var fieldArrayA
					var fieldArrayB
					var fieldA;
					var fieldB;
			
					if(a[tableField] == "&nbsp")
					{
						fieldA = "00000000";
					}
					else
					{
						fieldArrayA= a[tableField].split("/")
						fieldA = fieldArrayA[2] + fieldArrayA[0] + fieldArrayA[1]
					}
					/*else
					{
						fieldA = a[tableField]
					}
					*/
					if(b[tableField] == "&nbsp")
					{
						fieldB = "00000000";
					}
					else
					{
						fieldArrayB = b[tableField].split("/")
						fieldB = fieldArrayB[2] + fieldArrayB[0] + fieldArrayB[1]				
					}
			
					/*else
					{
						fieldB = b[tableField]
					}*/
				
					if (fieldA == fieldB)
						return(a[0] - b[0])
					else
						return(fieldA - fieldB)
				})
		
				if (direction == -1)
				itr.reverse();
				for(var i = 0; i < fieldCount; i++)
				{	
					fieldName = fieldValues[i] + "Sort";
					document.getElementById(fieldName).value = 1;
				}
				for(var i = 0; i < tableRows; i++)
				{
					viewText = "viewLink" + i;
					editText = "editLink" + i;
					deleteText = "deleteLink" + i;
		
					document.getElementById(viewText).href = "internal_trouble.php?internal_trouble.php?itrNo="+itr[i][0]+ "&action=view";
			
					if (match == 1)
					{
						document.getElementById(editText).href = "internal_trouble.php?itrNo="+itr[i][0]+ "&action=edit";
					}	
					/*document.getElementById(deleteText).href = "internal_trouble_process.php?itrNo="+itr[i][0]+ "&action=delete";*/
					for(var j = 0; j < fieldCount; j++)
					{
						documentText = fieldValues[j] + i;
						document.getElementById(documentText).innerHTML = itr[i][j];
					}
			
					//document.getElementById(itrText).innerHTML = totalRows;
			
				}
				if (direction == 1)
					newDirection = -1;
				if (direction == -1)
					newDirection = 1;
				document.getElementById(sortText).value = newDirection;
			}
		</script>
		<link rel="stylesheet" type="text/css" href="table.css">

</head>
<body>
	<h1>Internal Trouble Table</h1>
	<table>
		<!--Table Headings Go Here.  Can Click To Sort Table -->
		<!--<th>ITR NO</th><th>Inspection Date</th><th>Station</th><th>Dept Manager</th><th>Inspector</th><th>Part No</th><th>Operator</th><th>Inspection Summary</th><th>Discrepancies</th><th>Interim Containment</th><th>Corrective/</br>Preventve Action</th><th>Result of </br>Preventive Action</th><th>Department Manager</th><th>Date</th><th>QA Department Head</th><th>Date</th>-->
		<script type = "text/javascript">
			var tableFields = <?php echo $size; ?>;
			var sortAlpha;
			var sortDate;
			var sortNum;
			var tableRows = <?php echo $rows;?>;
			var sortType;
			//var 
			if(match == 1)
			{
				document.write("<th colspan = 2></th>");
			}
			else
				document.write("<th></th>");
			
			for(i = 0; i < tableFields; i++)
			{
					sortNum = "sortTableNum(" + i + ", "+ fieldValues[i] + ")";
					sortDate = "sortTableDate(" + i + ", " + fieldValues[i] + ")";
					sortAlpha = "sortTableAlpha(" + i + ", " + fieldValues[i] + ")";
					switch(i)
					{
						case 0:
							sortType = 'numeric';
							break;
						case 1:
						case 13: 
						case 15:
							sortType = 'date';
							break;
						default:
							sortType = 'alpha';
							break;
					}
				if (sortType == "numeric")
					document.write("<th onClick = '" + sortNum + "' class = 'headingText'> " + fieldNames[i] + "</th>");
				if (sortType == "date")
					document.write("<th onClick = '" + sortDate + "' class = 'headingText'> " + fieldNames[i] + "</th>");
				if (sortType == "alpha")
					document.write("<th onClick = '" + sortAlpha + "' class = 'headingText'> " + fieldNames[i] + "</th>");
			}
			</script>
			<tr>
			<script type = "text/javascript">
		
			//var fieldValue;
			
			for(var i = 0; i < tableRows; i++)
			{
				document.write("<tr><td><a name = 'viewLink" + i + "' id = 'viewLink" + i + "' href = 'internal_trouble.php?itrNo=" + itr[i][0] + "&action=view'>View</a></td>");
				if(match == 1)
				{
					document.write("<td><a name = 'editLink" + i + "' id = 'editLink" + i + "' href = 'internal_trouble.php?itrNo=" + itr[i][0] + "&action=edit'>Edit</a></td>");
					/*if(carPlantOne == 'A')
					{
						document.write("<td><a name = 'deleteLink" + i + "' id = 'deleteLink" + i + "'href = 'internal_trouble_process.php?itrNo=" + itr[i][0] + "action=delete'>Delete</a></td>");
					}*/
				}				
				for (var j = 0; j < tableFields; j++)
					document.write("<td name = '" + fieldValues[j] + i + "' id = '" + fieldValues[j] + i + "' class = 'tableText'>" + itr[i][j] + "</td>");
				document.write("</tr>");
			}
			for(var i = 0; i < tableFields; i++)
				document.write("<input type = 'hidden' name = '" + fieldValues[i] + "Sort' id = '" + fieldValues[i] + "Sort' value = 1 />");	
		</script>
	</table>
</body>