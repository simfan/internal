<?php
	ob_start();
	$host = "192.168.10.129";
	$user = "postgres";
	$pass = "pass";
	$db = "inven";
	$conn = pg_connect("host=$host dbname=$db user=$user password=$pass");
	if(!$conn)
	{
		die('Could not connect to database');
	}
	$itr_no = $_POST['itrNo'];
	$inspection_date = $_POST['iDate'];
	$station = $_POST['station'];
	$dept_manager_1 = $_POST['manager1'];
	$inspector = $_POST['inspector'];
	$part_no = $_POST['partNo'];
	$operator = $_POST['operator'];
	$inspection_summary = $_POST['summary'];
	$discrepancies = $_POST['discrepancies'];
	$interim_containment = $_POST['containment'];
	$corrective_action = $_POST['action'];
	$result = $_POST['result'];
	$dept_manager_2 = $_POST['manager2'];
	$manager_review_date = $_POST['reviewDate1'];
	$dept_head = $_POST['deptHead'];
	$head_review_date = $_POST['reviewDate2'];
	if ($_POST['submit'] == "Submit")
	{
		$query_max = "SELECT * FROM itr ORDER BY itr_no DESC LIMIT 1";
		$result_max = pg_query($conn, $query_max) or die("Error in query: $query_max. " . pg_last_error($conn));
		$max_row = pg_fetch_array($result_max);
		$max_itr_no = $max_row['itr_no'];
		$itr_no = $max_itr_no + 1;
		$query = "INSERT INTO itr (itr_no, inspection_date, station, dept_manager_1, inspector, part_no, operator, inspection_summary, discrepancies, interim_containment, corrective_action, result, dept_manager_2, manager_review_date, dept_head, head_review_date) VALUES('" .$itr_no . "', '" . $inspection_date . "', '" . $station . "', '" . $dept_manager_1 . "', '" . $inspector . "', '" . $part_no . "', '" . $operator . "', '" . $inspection_summary . "', '" . $discrepancies . "', '" . $interim_containment . "', '" . $corrective_action . "', '" . $result . "', '" . $dept_manager_2 . "', '" . $manager_review_date . "', '" . $dept_head . "', '" . $head_review_date . "' )";
	}
	
	if ($_POST['submit'] == "Edit")
	{
		$query = "UPDATE itr SET inspection_date = '" . $inspection_date . "', station = '" . $station . "', dept_manager_1 = '" . $dept_manager_1 . "', inspector = '" . $inspector . "', part_no = '" . $part_no . "', operator = '" . $operator . "', inspection_summary = '" . $inspection_summary . "', discrepancies = '" . $discrepancies . "', interim_containment = '" . $interim_containment . "', corrective_action = '" . $corrective_action . "', result = '" . $result . "', dept_manager_2 = '" . $dept_manager_2 . "', manager_review_date = '" . $manager_review_date . "', dept_head = '" . $dept_head . "', head_review_date = '" . $head_review_date . "' WHERE itr_no = '" . $itr_no . "'";
	}
	//print $query;
	$result = pg_query($conn, $query) or die("Error in query: $query." . pg_last_error($conn));
	$query = "COMMIT";
	$result = pg_query($conn, $query) or die("Error in query: $query" . pg_last_error($conn));
	header("Location: index.php");
	ob_end_flush();
?>