<?php

	$host = "192.168.10.129";
	$user = "postgres";
	$pass = "pass";
	$db = "inven";
	$conn = pg_connect("host=$host dbname=$db user=$user password=$pass");
	if(!$conn)
	{
		die('Could not connect to database');
	}
	
	require "check_login.php";
	$screen = 3;
	$itr_no = '';
	$inspection_date = '';
	$station = '';
	$dept_manager_1 = '';
	$inspector = '';
	$part_no =  '';
	$operator = '';
	$inspection_summary = '';
	$discrepancies = '';
	$interim_containment = '';
	$corrective_action = '';
	$result = '';
	$dept_manager_2 = '';
	$manager_review_date = '';
	$qa_dept_head = '';
	$head_review_date = '';	
	$submit = "Submit";
	if ($_GET['action'] == 'edit' || $_GET['action'] == 'view')
	{
		$query = "SELECT * FROM itr WHERE itr_no = '" . $_GET['itrNo'] . "'";
		$result = pg_query($conn, $query) or die("Error in query: $query " . pg_last_error($conn));
		$itr = pg_fetch_array($result);
		$itr_no = $itr['itr_no'];
		$inspection_date = $itr['inspection_date'];
		$station = $itr['station'];
		$dept_manager_1 = $itr['dept_manager_1'];
		$inspector = $itr['inspector'];
		$part_no =  $itr['part_no'];
		$operator = $itr['operator'];
		$inspection_summary = $itr['inspection_summary'];
		$discrepancies = $itr['discrepancies'];
		$interim_containment = $itr['interim_containment'];
		$corrective_action = $itr['corrective_action'];
		$result = $itr['result'];
		$dept_manager_2 = $itr['dept_manager_2'];
		$manager_review_date = $itr['manager_review_date'];
		$qa_dept_head = $itr['dept_head'];
		$head_review_date = $itr['head_review_date'];
		if ($_GET['action'] == 'edit')
			$submit = "Edit";
	}
	
?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="left_border.css">
	<script src = "left_border.js"></script>
</head>
<body>
	<?php require "left_border.php";?>
	<div class = "mainTable">
	<form name =  'incrForm' action = 'internal_trouble_process.php' method = 'post'>
	<?php print "<input type = 'hidden' name = 'itrNo' id = 'itrNo' value = $itr_no />";?> 
	<table>
		<tr>
			<td colspan = 2><h3>INTERNAL TROUBLE REPORT</h3></td><td colspan = 2><?php if ($_GET['action'] == 'edit' || $_GET['action'] == 'view'){ print "<h3>ITR NO: $itr_no </h3>"; }?></td>
		</tr>
		<tr><td colspan = 4><hr/></td></tr>
		<tr>
			<?php print '<td>Inspection Date <input type = "text" name = "iDate" id = "iDate" size = 10 maxlength = 10 value = "' . $inspection_date . '"';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print ' /></td><td>Station <input type = "text" name = "station" id = "station" value = "' . $station . '" size = 20 maxlength = 20 ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print ' /></td><td>Dept. Manager <input type = "text" name = "manager1" id = "manager1" value = "' . $dept_manager_1 . '" size = 25 maxlength = 25 ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print ' /></td><td>Inspector: <input type = "text" name = "inspector" id = "inspector" value = "' . $inspector . '" size = 25 maxlength = 25 ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print '/></td>';?>
		</tr>
		<tr>
			<?php print '<td>Part No. <input type = "text" name = "partNo" id = "partNo" size = 20 maxlength = 20 value = "' . $part_no . '" ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			} 
			print ' /></td><td>Operator <input type = "text" name = "operator" id = "operator" size = 25 maxlength = 25 value = "' . $operator . '" ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print '/></td><td colspan = 2></td>';?>
		</tr>
		<tr>
			<?php print '<td colspan = 4 valign = "baseline" class = "bold">Inspection Summary</br><textarea rows = 4 cols = 90 name = "summary" id = "summary" maxlength = 300 ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print ' >' . $inspection_summary . '</textarea></td>';?>
		</tr>
		<tr>
			<?php print "<td colspan = 4 valign = 'baseline' class = 'bold'>Discrepancies</br><textarea rows = 4 cols = 90 name = 'discrepancies' id = 'discrepancies' maxlength = 300 ";
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print " >$discrepancies</textarea></td>";?>
		</tr>
		<tr>
			<?php print "<td colspan = 4 valign = 'baseline' class = 'bold'>Interim Containment</br><textarea rows = 5 cols = 90 name = 'containment' id = 'containment' maxlength = 400 ";
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print " >$interim_containment</textarea></td>";?>
			
		</tr>
		<tr>
			<?php print "<td colspan = 4 valign = 'baseline' class = 'bold'>Corrective Action/Preventive Action</br><textarea rows = 8 cols = 90 name = 'action' id = 'action' maxlength = 700 ";
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print " >$corrective_action</textarea></td>"; ?>
		</tr>
		<tr>
			<?php print "<td colspan = 4 valign = 'baseline' class = 'bold'>Result of Preventive Action</br><textarea rows = 12 cols = 90 name = 'result' id = 'result' maxlength = 1000 ";
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print " >$result</textarea></td>"; ?>
		</tr>
		<tr>
			<td colspan = 4>Review By</td>
		</tr>
		<tr>
			<td colspan = 2>Department Manager: <?php print '<input type = "text" name = "manager2" id = "manager2" size = 25 maxlength = 25 value = "' . $dept_manager_2 . '" ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print ' />';?>
			</td><td colspan = 2>Date: <?php print '<input type = "text" name = "reviewDate1" id = "reviewDate1" size = 10 maxlength = 10 value = "' . $manager_review_date . '" ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print ' />';?></td>
		</tr>
		<tr>
			<td colspan = 2>QA Department Head: <?php print '<input type = "text" name = "deptHead" id = "deptHead" size = 25 maxlength = 25 value = "' . $qa_dept_head . '" ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print ' />';?></td><td colspan = 2>Date: <?php print '<input type = "text" name = "reviewDate2" id = "reviewDate2" size = 10 maxlength = 10 value = "' . $head_review_date . '" ';
			if($_GET['action'] == 'view')
			{
				print 'readonly = readonly';
			}
			print ' />';?></td>
		</tr>		
	</table>
	<?php if ($_GET['action'] == 'view') { print '<input type="button" value="Back" onClick="history.go(-1);return true;">'; }else { print "<input type = 'submit' name = 'submit' id = 'submit' value = $submit />"; } ?>
	</form>
	</div>
</body>
</html>